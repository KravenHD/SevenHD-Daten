from imports import *
from Tools.Directories import fileExists, pathExists
if fileExists('/usr/lib/enigma2/python/Plugins/Extensions/JobManager/plugin.pyo'):
    from Plugins.Extensions.JobManager.plugin import *
    JobManagerInstalled = True
else:
    JobManagerInstalled = False
UserAgent = 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13'

class m2list(MenuList):

    def __init__(self, list):
        MenuList.__init__(self, list, False, eListboxPythonMultiContent)
        self.l.setFont(0, gFont('Regular', 14))
        self.l.setFont(1, gFont('Regular', 16))
        self.l.setFont(2, gFont('Regular', 18))
        self.l.setFont(3, gFont('Regular', 20))
        self.l.setFont(4, gFont('Regular', 22))
        self.l.setFont(5, gFont('Regular', 24))
        self.l.setFont(6, gFont('Regular', 26))
        self.l.setFont(7, gFont('Regular', 28))
        self.l.setFont(8, gFont('Regular', 32))


def cat_(letter, link, img):
    res = [(letter, link, img)]
    res.append(MultiContentEntryText(pos=(0, 0), size=(800, 40), font=8, text=letter, flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER))
    return res


class streamking(Screen):

    def __init__(self, session):
        sz_w = getDesktop(0).size().width()
        if sz_w == 1920:
            path = '/usr/lib/enigma2/python/Plugins/Extensions/Albatros/skin/defaultListScreen_new.xml'
        else:
            path = '/usr/lib/enigma2/python/Plugins/Extensions/Albatros/skin/defaultListScreen.xml'
        with open(path, "r") as f:
            self.skin = f.read()
            f.close()
        self.session = session
        Screen.__init__(self, session)
        self['actions'] = ActionMap(['OkCancelActions',
         'ColorActions',
         'DirectionActions',
         'MovieSelectionActions'], {'up': self.up,
         'down': self.down,
         'left': self.left,
         'right': self.right,
         'ok': self.ok,
         'cancel': self.exit,
         'red': self.exit,
         'blue': self.dnitnow}, -1)
        self['menulist'] = m2list([])
        self['title'] = Label('Streamking')
        self['text'] = Label('')
        self['poster'] = Pixmap()
        self['red'] = Label(_('Exit'))
        self['green'] = Label('')
        self['yellow'] = Label(_(' '))
        self['blue'] = Label('')
        self['Menu'] = Label(_(' '))
        self['name'] = Label('')
        self.dnfile = 'False'
        self.currentList = 'menulist'
        self.menulist = []
        self.loading_ok = False
        self.check = 'abc'
        self.count = 0
        self.loading = 0
        self.dir()
        self.onLayoutFinish.append(self.abc)

    def about(self):
        self.session.open(AboutScreen)

    def jobix(self):
        if JobManagerInstalled:
            self.session.open(JobManagerFrontEnd)

    def dnitnow(self):
        if JobManagerInstalled and self.check == 'letter_movie':
            self.dnfile = 'True'
            link = self['menulist'].getCurrent()[0][1]
            self.filmname = self['menulist'].getCurrent()[0][0]
            self.get_play_link(self.filmname, link)

    def up(self):
        self[self.currentList].up()

    def down(self):
        self[self.currentList].down()

    def left(self):
        self[self.currentList].pageUp()

    def right(self):
        self[self.currentList].pageDown()

    def switchList(self):
        if self.currentList == 'menulist':
            self['ButtonBlue'].hide()
            self['TextBlue'].hide()
            self['menulist'].selectionEnabled(0)
            self.currentList = 'menulist2'
            self.check = 'abc'
        else:
            self['ButtonBlue'].show()
            self['TextBlue'].show()
            self['menulist'].selectionEnabled(1)
            self.currentList = 'menulist'
            self.check = 'letter_movie'

    def abc(self):
        self.loading_ok = False
        self.check = 'abc'
        self.currentList = 'menulist'
        self.letter_list = []
        self.letter_movielist = []
        self['menulist'].selectionEnabled(1)
        self['menulist'].show()
        self.genre_name = 'sports'
        url = 'http://www.streamking.info/'
        getPage(url, method='GET', headers={'Content-Type': 'application/x-www-form-urlencoded',
         'UserAgent': 'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.13 (KHTML, like Gecko) Chrome/24.0.1290.1 Safari/537.13'}).addCallback(self.load_data_channels)

    def load_data_channels(self, data):
        print 'got data - now processing channel_list'
        matches=re.findall('<td><img src="(.*?)" height="20" width="23" /><span class="result-table-tag".*?sans-serif;">(.*?)</span> <b>(.*?)</b>.*?</td>.*?<td>(.*?)</td><td><a href="(.*?)" title=".*?" class="button black-button">Watch now</a>',data,re.DOTALL)
        channels = re.findall('<a href="(.*?)"><img src="(.*?)" border="0" height="12" class="channel tip" title="Watch (.*?)"/></a>', data)
        print matches
        #print channels
        #if channels:
        #    for each in channels:
        #        url, img,name = each
        #        print name, url
        #        url='http://www.streamking.info/'+url
        #        img=url='http://www.streamking.info/'+img
        #        self.letter_list.append(cat_(name, url,img))
        if matches:
            for (img,competition,match,time,url) in matches:
                img = 'http://www.streamking.info/'+img
                info = time+' - '+competition+' : '+match
                url='http://www.streamking.info/'+url
                self.letter_list.append(cat_(info, url,img))                

        self['menulist'].l.setList(self.letter_list)
        self['menulist'].l.setItemHeight(40)
        self['menulist'].moveToIndex(0)

    def ok(self):
        if self.check == 'abc':
            selectedEntry = self['menulist'].l.getCurrentSelection()[0][1]
            selectedName = self['menulist'].l.getCurrentSelection()[0][0]
            self.loading_ok = False
            uri = selectedEntry
            uri = str(uri).replace('channel', 'streams/stream')
            print uri
            req = urllib2.Request(uri)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
            req.add_header('Referer', 'http://www.streamking.org/streams/stream1.html')
            #req.add_header('Host', 'www.hdcast.org')
            page = urllib2.urlopen(req)
            response = page.read()
            #print response
            #<iframe class="video" src="/streams/stream2.html" width="650" height="410" scrolling="no" frameborder="0">Your browser does not support frames, so you will not be able to view this page.</iframe>
            new_page=re.findall('<iframe class="video" src="(.*?)" width="..." height="..." scrolling="no" frameborder="0">Your browser does not support frames, so you will not be able to view this page.</iframe>',response)
            if new_page:
                url='http://www.streamking.info'+new_page[0]
                print url
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                req.add_header('Referer', 'http://www.streamking.org/streams/stream1.html')
                #req.add_header('Host', 'www.hdcast.org')
                page = urllib2.urlopen(req)
                answer = page.read()
                print answer
				#<script type="text/javascript"> fid="llive1"; v_width=640; v_height=400;</script><script type="text/javascript" src="http://hdcast.org/embedlive44.js"></script>
                update_parameter = re.findall('<script type="text/javascript"> fid="(.*?)"; v_width=...; v_height=...;</script><script type="text/javascript" src="http://hdcast.org/embedlive44.js"></script>', answer)
                if update_parameter:
                    uri = 'http://www.hdcast.org/embedlive44.php?u=' + update_parameter[0] + '&vw=640&vh=400&domain=www.streamking.org'
                    print uri
                    req = urllib2.Request(uri)
                    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
                    req.add_header('Referer', 'http://www.streamking.org/streams/stream1.html')
                    req.add_header('Host', 'www.hdcast.org')
                    page = urllib2.urlopen(req)
                    response = page.read()
                    print response
                    streamer = re.findall("'streamer':.*?'(.*?)',", response)
                    flashplayer = 'http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/bba.swf'
                    file = re.findall("'file':.*?'(.*?)',", response)
                    streamer = 'rtmp://secure.hdcast.org/justforvip/'
                    final_url = streamer + ' playpath=' + file[0] + ' swfUrl=' + flashplayer + ' live=1 pageUrl=' + uri + ' token=Fo5_n0w?U.rA6l3-70w47'
                    print final_url
                    self.play_that_shit(final_url)

    def play_that_shit(self, data):
        selectedName = self['menulist'].l.getCurrentSelection()[0][0]
        sref = eServiceReference(4097, 0, data)
        sref.setName(selectedName)
        self.session.open(MoviePlayer, sref)

    def exit(self):
        self.session.close(MoviePlayer)
        self.close()

    def load_poster_teledunet(self):
        jp_link = self['menulist'].getCurrent()[0][2]
        tmp_image = jpg_store = '/tmp/highlive_poster.jpg'
        try:
            downloadPage(jp_link, tmp_image).addCallback(self.downloadPic, tmp_image)
        finally:
            print "Error: can't find file or read data"

    def show_cover(self):
        jpg_link = '/usr/lib/enigma2/python/Plugins/Extensions/highlive/images/'
        jpg_name = 'no_cover.png'
        jpg_store = jpg_link + jpg_name
        if not os.path.exists(jpg_store):
            self.downloadPic(file_name, jpg_store)
        else:
            self.poster_resize(jpg_store)

    def downloadPic(self, data, jpg_store):
        if fileExists(jpg_store):
            self.poster_resize(jpg_store)
        else:
            print '[highlive] logo not found'

    def poster_resize(self, poster_path):
        self['poster'].instance.setPixmap(None)
        self['poster'].hide()
        sc = AVSwitch().getFramebufferScale()
        self.picload = ePicLoad()
        size = self['poster'].instance.size()
        self.picload.setPara((size.width(),
         size.height(),
         sc[0],
         sc[1],
         False,
         1,
         '#FF000000'))
        if self.picload.startDecode(poster_path, 0, 0, False) == 0:
            ptr = self.picload.getData()
            if ptr != None:
                self['poster'].instance.setPixmap(ptr)
                self['poster'].show()
            else:
                print '[highlive] no cover.. error'
        return

    def stream_not_found(self):
        message = self.session.open(MessageBox, _('Stream not found, try again later on'), MessageBox.TYPE_INFO, timeout=3)

    def errorload2(self, error):
        print '[highlive] error %s' % error
        count_movies = len(self.letter_movielist)
        self.loading_ok = True
        self.loading = 0
        self.count = 0

    def errorload(self, error):
        print error

    def dir(self):
        if not pathExists('/tmp/highlive/'):
            os.system('mkdir /tmp/highlive/')
        else:
            print '[highlive] /tmp/highlive/ allready present'


def main(session, **kwargs):
    session.open(streamking)


def Plugins(path, **kwargs):
    global plugin_path
    plugin_path = path
    return [PluginDescriptor(name='Teledunet', description='Teledunet Streamer', where=[PluginDescriptor.WHERE_PLUGINMENU], fnc=main, icon='plugin.png')]